document.write("<p>Idioma del navegador: ")
document.write(infoNavegador.idioma);
document.write("</p>")