document.write("<h3>");
document.write(info.centro);
document.write("</h3>");