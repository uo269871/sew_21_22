document.write("<h2>");
document.write(info.titulacion);
document.write("</h2>");