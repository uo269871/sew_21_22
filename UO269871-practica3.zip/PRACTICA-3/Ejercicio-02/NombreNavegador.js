document.write("<p>Nombre del navegador: ");
document.write(infoNavegador.nombre);
document.write("</p>");