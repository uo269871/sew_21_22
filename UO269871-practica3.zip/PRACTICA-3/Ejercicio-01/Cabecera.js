var info = new Object();
info.asignatura = "Software y estándares para la web";
info.centro = "Escuela de Ingeniería Informática";
info.titulacion = "Grado en Ingeniería Informática del Software";
info.universidad = "Universidad de Oviedo";
info.curso = "2021-2022";
info.alumno = "Miguel Menéndez Rodríguez";
info.correo = "UO269871@uniovi.es";